import os, datetime, time

date_write = datetime.datetime.now()

def start_test():
    FRS = open('Number-System\\files\log\log.txt', 'a', encoding='utf-8')
    FRS.write('root:StartCode "go" - ' + str(date_write) + '\n')
    FRS.close()
    try:
        from files.main import start_main
        FRT = open('Number-System\\files\\test\\test_log.txt', 'w', encoding='utf-8')
        FRT.write(' root:FileCode "main" - installed - ' + str(date_write) + '\n')
    except ImportError:
        FRT.write('root:FileCode "main" - not installed - ' + str(date_write) + '\n')
        pass
    try:
        from files.wrn.warn import keyboard, file_not_found, i_e_colo, i_e_requ
        FRT.write('root:FileCode "warn" - installed - ' + str(date_write) + '\n')
    except ImportError:
        FRT.write('root:FileCode "warn" - not installed - ' + str(date_write) + '\n')
        pass
    try:
        from files.services import break_num
        FRT.write('root:FileCode "break_num" - installed - ' + str(date_write) + '\n')
    except ImportError:
        FRT.write('root:FileCode "break_num" - not installed - ' + str(date_write) + '\n')
        pass
    try:
        from files.services import break_cell
        FRT.write('root:FileCode "break_cell" - installed - ' + str(date_write) + '\n')
    except ImportError:
        FRT.write('root:FileCode "break_cell" - not installed - ' + str(date_write) + '\n')
        pass
    try:
        from colorama import Fore, Style, Back
        FRT.write('root:Component "Colorama" - installed - ' + str(date_write) + '\n')
    except ImportError:
        FRT.write('root:Component "Colorama" - not installed - ' + str(date_write) + '\n')
        pass
    try:
        import requests
        FRT.write('root:Component "Requests" - installed - ' + str(date_write) + '\n')
    except ImportError:
        FRT.write('root:Component "Requests" - not installed - ' + str(date_write) + '\n')
        pass
    FRT.close()

    FRR = open('Number-System\\files\\test\\test_log.txt', 'r', encoding='utf-8')
    print(*FRR)
    time.sleep(10)
    FRR.close()