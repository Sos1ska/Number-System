import os, datetime

date_write = datetime.datetime.now()

def cl():
    os.system("clear")

def file_not_found():
    cl()
    print('Проверьте все папки и файлы на правильность')
    print()
    print('Ошибка FileNotFoundError, исправление ошибки можете по github ссылке https://github.com/Sos1ska/RepairsCode')
    quit()

def keyboard():
    cl()
    FRW = open('Number-System\\files\log\log.txt', 'a', encoding='utf-8')
    FRW.write('root:Warning "KeyboardInterrupt" - ' + str(date_write) + '\n')
    FRW.close()
    cl()
    print('Сохранено по пути Number-System/files/log/log.txt')
    quit()

def i_e_colo():
    cl()
    print('Не установлен компонент Colorama')
    FRE = open('Number-System\\files\log\log.txt', 'a', encoding='utf-8')
    FRE.write('root:ImportError "Colorama" - ' + str(date_write) + '\n')
    FRE.close()
    quit()

def i_e_requ():
    cl()
    print('Не установлен компонент Requests')
    FRE = open('Number-System\\files\log\log.txt', 'a', encoding='utf-8')
    FRE.write('root:ImportError "Requests" - ' + str(date_write) + '\n')
    FRE.close()
    quit()