from files.wrn.warn import keyboard, file_not_found, i_e_colo, i_e_requ
import os, datetime

date_write = datetime.datetime.now()

try:
    from colorama import Fore, Style, Back
except ImportError:
    i_e_colo()
try:
    import requests, urllib.request
except ImportError:
    i_e_requ

def cl():
    os.system("clear")

def start_cell():
    global cl
    try:
        try:
            FRI = open('Number-System\\files\log\log.txt', 'a', encoding='utf-8')
            FRS = open("Number-System\\files\log\log.txt", 'a', encoding='utf-8')
        except FileNotFoundError:
            file_not_found()
        latitude_tower_input = float(input(Fore.YELLOW + "Введите широту: " + Style.RESET_ALL))
        longitude_tower_input = float(input(Fore.YELLOW + "Введите долготу: " + Style.RESET_ALL))
        print(Fore.YELLOW + f"Вставьте данную ссылку в любой браузер:\n" + Style.RESET_ALL)
        print(f"https://opencellid.org/#zoom=13&lat={str(latitude_tower_input)}&lon={str(longitude_tower_input)}")
    except KeyboardInterrupt:
        keyboard()