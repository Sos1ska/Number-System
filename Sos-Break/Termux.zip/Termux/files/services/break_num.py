from files.wrn.warn import file_not_found, keyboard, i_e_requ, i_e_colo
import os, datetime

date_write = datetime.datetime.now()

try:
    from colorama import Fore, Style, Back
except ImportError:
    i_e_colo()
try:
    import requests, urllib.request
except ImportError:
    i_e_requ()
def cl():
    os.system("clear")

def start_num():
    global cl
    try:
        try:
            FRI = open('Number-System\\files\log\log.txt', 'a', encoding='utf-8')
            FRS = open('Number-System\\files\log\log.txt', 'a', encoding='utf-8')
        except FileNotFoundError:
            file_not_found()
        FRS.write('root:StartCode "break_num" - ' + str(date_write) + '\n')
        FRS.close()
        print(Fore.YELLOW + 'Введите номер телефона Пример:' + Style.RESET_ALL, Fore.CYAN + '+79515200611' + Style.RESET_ALL)
        number_input = input(Fore.GREEN + '/Sos/break_num/>>> ' + Style.RESET_ALL)
        getinfonum = f'https://htmlweb.ru/geo/api.php?json&telcod={str(number_input)}'
        try:
            infoNumber = urllib.request.urlopen( getinfonum )
        except:
            print('[!] - Номер введён неверно - [!]')
            sleep(5)
            q()
        infoNumber = json.load( infoNumber )
        try:
            print(f"Страна >>> ", infoNumber["country"]["fullname"])
        except KeyError:
            print(f"Cтрана >>> Не удалось определить")
        try:
            print(f"Столица >>> ", infoNumber["capital"]["name"])
        except KeyError:
            print(f"Столица >>> Не удалось определить")
        try:
            print(f"Широта столицы >>> ", infoNumber["capital"]["latitude"])
        except KeyError:
            print(f"Широта столицы >>> Не удалось определить")
        try:
            print(f"Долгота столицы >>> ", infoNumber["capital"]["longitude"])
        except KeyError:
            print(f"Долгота столицы >>> Не удалось определить")
        try:
            print(f"Тип времени >>> +", infoNumber["capital"]["time_zone"])
        except KeyError:
            print(f"Тип времени >>> Не удалось определить")
        try:
            print(f"Код номера >>> ", infoNumber["country"]["country_code3"])
        except KeyError:
            print(f"Код номера >>> Не удалось опеределить")
        try:
            print(f"MCC номера >>> ", infoNumber["country"]["mcc"])
        except KeyError:
            print(f"MCC номера >>> Не удалось оперделить")
        try:
            print(f"Регион >>> ", infoNumber["region"]["name"])
        except KeyError:
            print(f"Регион >>> Не удалось определить")
        try:
            print(f"Округ >>> ", infoNumber["region"]["okrug"])
        except KeyError:
            print(f"Округ >>> Не удалось определить")
        try:
            print(f"Код региона >>> ", infoNumber["region"]["autocod"])
        except KeyError:
            print(f"Код региона >>> Не удалось определить")
        try:
            print(f"Город >>> ", infoNumber["0"]["name"])
        except KeyError:
            print(f"Город >>> Не удалось определить")
        try:
            print(f"Широта города >>> ", infoNumber["0"]["latitude"])
        except KeyError:
            print(f"Широта города >>> Не удалось определить")
        try:
            print(f"Долгота города >>> ", infoNumber["0"]["longitude"])
        except KeyError:
            print(f"Долгота города >>> Не удалось определить")
        try:
            print(f"Oper_id >>> ", infoNumber["0"]["oper_id"])
        except KeyError:
            print(f"Oper_id >>> Не удалось определить")
        try:
            print(f"Радиус номеров телефонов >>> ", infoNumber["0"]["def"])
        except KeyError:
            print(f"Радиус номеров телефоно >>> Не удалось определить")
        try:
            print(f"Рабочесть телефона >>> ", infoNumber["0"]["mobile"])
        except KeyError:
            print(f"Рабочесть телефона >>> Не удалось определить")
        try:
            print(f"Оператор >>> ", infoNumber["0"]["oper"])
        except KeyError:
            print(f"Оператор >>> Не удалось определить")
        print(f"https://api.whatsapp.com/send?phone={str(number_input)}&text=You,%20are&20hacked%20by%20by%20the%20Cool-Hackers - Поиск номера в", Fore.GREEN + "WhatsApp" + Style.RESET_ALL) 
        print(f"https://facebook.com/login/identify/?ctx=recover&ars=royal_blue_bar - Поиск номера в", Fore.BLUE + "Facebook" + Style.RESET_ALL)
        print(f"https://linkedin.com/checkpoint/rp/request-password-reset-submit - Поиск номера в Linkedin")
        print(f"https://viber://add?number={str(number_input)} - Поиск номера в", Fore.MAGENTA + "Viber" + Style.RESET_ALL)
        print(f"https://skype:{str(number_input)}?call - Звонок через", Fore.BLUE + "Skype" + Style.RESET_ALL)
        print(f"tel:{str(number_input)} - Простой звонок")
    except KeyboardInterrupt:
        keyboard()