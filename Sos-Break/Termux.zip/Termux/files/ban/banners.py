import datetime, os
from time import sleep

date_write = datetime.datetime.now()

def start_code():
    FRS = open('Number-System\\files\log\log.txt', 'a', encoding='utf-8')
    FRS.write('root:StartCode "banners" - ' + str(date_write) + '\n')
    FRS.close()
    print(f"S"),sleep(0.5),print(f" O"),sleep(0.5),print(f"  S"),sleep(0.5),print(f"   1"),sleep(0.5),print(f"    S"),sleep(0.5),print(f"     K"),sleep(0.5),print(f"      A"),sleep(2)

def second_number():
    print('''
    .---------------------------------------------.
    |               Выберите функцию              |
    | ___________________________________________ |
    | break_num - Пробив номера телефона          |
    | break_cell - Просмотр карты с передатчиками |
    '---------------------------------------------'
    ''')