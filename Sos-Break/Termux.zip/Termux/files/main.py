from files.services.break_num import start_num
from files.services.break_cell import start_cell
from files.wrn.warn import i_e_colo, i_e_requ, file_not_found, keyboard
from files.ban.banners import start_code, second_number
import os, datetime

try:
    from colorama import Fore, Style, Back
except ImportError:
    i_e_colo()
try:
    import requests
except ImportError:
    i_e_requ()

date_write = datetime.datetime.now()

def cl():
    os.system("clear")

def start_main():
    global cl
    try:
        cl()
        try:
            FRS = open('Number-System\\files\log\log.txt')
        except FileNotFoundError:
            file_not_found()
        FRS.write('root:StartCode "main" - ' + str(date_write) + '\n')
        FRS.clsoe()
        start_code()
        cl()
        while True:
            cl()
            second_number()
            while True:
                menu = input(Fore.RED + Style.BRIGHT + '> ' + Style.RESET_ALL + Style.NORMAL)
                if str(menu) == "break_num":
                    start_num()
                elif str(menu) == "break_cell":
                    start_cell()
                else:
                    print(Fore.RED + Style.BRIGHT + 'Неккоретная команда' + Style.RESET_ALL + Style.NORMAL, f": {str(menu)}")
    except KeyboardInterrupt:
        keyboard()