from files.wrn.warn import file_not_found, keyboard
from files.test.go import start_test
from files.main import start_main
import os, datetime

date_write = datetime.datetime.now()

def cl():
    os.system("clear")

try:
    try:
        FRS = open('Number-System\\files\log\log.txt', 'a', encoding='utf-8')
    except FileNotFoundError:
        file_not_found()
    FRS.write('root:StartCode "breaknumber" - ' + str(date_write) + '\n')
    FRS.close()
    start_test()
    cl()
    start_main()
except KeyboardInterrupt:
    keyboard()